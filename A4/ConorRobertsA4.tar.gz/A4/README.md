
# CIS3490 - Assignment 4

**Name:** Conor Roberts
**ID:** #1056167
**Date:** March 29, 2021

## About

I didn't do Q2. Hoping for some part marks here and there but ultimately I couldn't do it.

## Usage

Compile with "make"
Run with "./Q1 {filename.txt}"
