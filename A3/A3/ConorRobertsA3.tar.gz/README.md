# Assignment #3

## About

**Name:** Conor Roberts
**ID:** #1056167
**Date:** March 15, 2021

## Usage

**Compilation:** make
**Execution:** ./main <p1_file.txt> <p2_file.txt>

## Q2.4

The Horspool algorithm used in P23 is roughly 8x faster than the brute force method used in P22.
