#include <stdlib.h>
#include <stdio.h>
#include <string.h>

/**
 * @brief Assignment 2
 * @author Conor Roberts (#1056167)
 * @date February 22nd, 2021
 * 
 */


void bruteInversionCount(int *arr, int len, int *inversions, int *operations);

void divideInversionCount(int *arr, int len, int *inversions, int *operations);