# Assignment 2
This assignment does a bunch of stuff that I did not find very enjoyable or useful. P1 counts the number of inversions within some data in a really bad way and then in a really good way. P2 creates a convex hull from a set of data. P2 does this in a really bad way and then in a really good way. Why was I asked to make it in a bad way? I do not know. 

## About
Name: Conor Roberts
Student ID: 1056167
Date: February 22nd, 2021